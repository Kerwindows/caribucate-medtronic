const QUERIES = {
  USERS_LIST: 'users-list',
}

export {QUERIES}
